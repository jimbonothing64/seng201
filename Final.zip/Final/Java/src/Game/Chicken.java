package Game;
/**
 * chicken is a type of farm animal and
 *  child class that inherits animal superclass.
 * @author will
 *
 */
/**
 * calls the super() constructor of the
 * animal superclass with default
 * attributes of the chicken class
 * @author will
 *
 */
public class Chicken extends Animal {
	public Chicken() {
		super("chicken", 3, 1, 1, 1);
	}
}